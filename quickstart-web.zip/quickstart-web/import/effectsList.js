export const importedEffectsList = [
  // Place your effect zip-file to import folder and add here zip-file name. Example:
  //'your_effect_1.zip',
  // 'your_effect_2.zip'
];
